<?php
// Inserção das variaveis para utilização do sistema, aqui fica as configurações de conexão do banco de dados
$nome_Oficina = "Watanabe & Hilgemberg SA";
  $url_Oficina = "http://localhost/git/software/Sistemas/Oficina/Sistemas/";
  $endereco_Oficina = "Avenida MInas Gerais, 565, Centro, Primavera do Leste - MT";
   $telefone_Oficina = "066 3498 0571"; 
  $celular_Oficina = "066 9 9975 4921";
$email_Oficina = "suporteglpihilgemberg@gmail.com";
//Dados acima serão substituido pelo banco de dados 

//Variáveis do banco de dados
$servidor_Oficina ="localhost";
 $usuario_Oficina = "root";
  $senha_Oficina = "";
$bancoBD_Oficina = "oficina";
?>